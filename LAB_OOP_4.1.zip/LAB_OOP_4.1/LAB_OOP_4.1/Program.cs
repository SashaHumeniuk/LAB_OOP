﻿class Auto
    {
        int count { get; set; }

        public Auto(int count)
        {
            this.count = count;
        }

        public virtual string ToString()
        {
           return $"Авто : {count}";
        }
    }


    class Dvigun : Auto
    {
        string name { get; set; }

        public Dvigun(int count, string name) : base(count)
        {
            this.name = name;
        }

        public override string ToString()
        {
            return $"{name} - Ї'де та заправляється.";
        }
    }

    class Koleso
    {
        string info { get; set; }

        public Koleso(string info)
        {
            this.info = info;
        }

        public void Display()
        {
            Console.WriteLine($"Коли міняти - {info}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Auto[] s = {
                new Dvigun(3, "Ауді")
            };

            foreach (Auto str in s)
            {
                Console.WriteLine(str.ToString());
            }

            Koleso koleso = new Koleso("перед зимою міняти колеса.");
            koleso.Display();
        }
    }
