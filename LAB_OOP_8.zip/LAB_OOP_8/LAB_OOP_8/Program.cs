﻿using System.Text;

class Program
{
    static void Main(string[] args)
    {
        string path_d = "D:\\OOP_lab08";

        void Copy(string path_1, string path_2)
        {
            try
            {
                if ((!Directory.Exists(path_1) || !Directory.Exists(path_2)) || (!Directory.Exists(path_1) && !Directory.Exists(path_2)))
                {
                    Console.WriteLine($"Не iснує потрiбних каиалогів!!!");
                }
                else
                {
                    DirectoryInfo dirinf1 = new DirectoryInfo(path_1);
                    DirectoryInfo dirinf2 = new DirectoryInfo(path_2);
                    string name = dirinf1.Name;
                    Directory.CreateDirectory(path_2 + $@"\{name}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        void Moving(string path_1, string path_2)
        {
            try
            {
                if (!Directory.Exists(path_1))
                {
                    Console.WriteLine($"Не iснує потрiбних каталогів!!!");
                }
                else
                {
                    DirectoryInfo dirinf = new DirectoryInfo(path_2);
                    if (dirinf.Exists)
                    {
                        dirinf.Delete(true);
                    }
                    new DirectoryInfo(path_1).MoveTo(path_2);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        try
        {
            Directory.CreateDirectory(path_d);
            Directory.CreateDirectory(path_d + "\\KNms1-B21");
            Directory.CreateDirectory(path_d + "\\Humeniuk");
            Directory.CreateDirectory(path_d + "\\Sources");
            Directory.CreateDirectory(path_d + "\\Reports");
            Directory.CreateDirectory(path_d + "\\Texts");
            Copy(path_d + "\\Texts", path_d + "\\Humeniuk");
            Copy(path_d + "\\Sources", path_d + "\\Humeniuk");
            Copy(path_d + "\\Reports", path_d + "\\Humeniuk");
            Moving(path_d + "\\Humeniuk", path_d + "\\KNms1-B21");
            if (!File.Exists(path_d + "\\Texts\\dirinfo.txt"))
            {
                File.Create(path_d + "\\Texts\\dirinfo.txt");
            }
            if (File.Exists(path_d + "\\Texts\\dirinfo.txt") == true)
            {
                string dirName = "path_d" + "\\Texts";
                DirectoryInfo dirInfo = new DirectoryInfo(dirName);
                string text = $"Назва каталогу: {dirInfo.Name}\nРозташування каталогу: {dirInfo.FullName}\nЧас створення каталогу: {dirInfo.CreationTimeUtc}\nКореневий каталог: {dirInfo.Root}";
                using (FileStream fstream = new FileStream(path_d + "\\Texts\\dirinfo.txt", FileMode.Create))
                {
                    byte[] array = Encoding.Default.GetBytes(text);
                    fstream.Write(array, 0, array.Length);
                }
                using (FileStream fstream = File.OpenRead(path_d + "\\Texts\\dirinfo.txt"))
                {
                    byte[] array = new byte[fstream.Length];
                    fstream.Read(array, 0, array.Length);
                    text = Encoding.Default.GetString(array);
                }
                Console.WriteLine($"У файлi dirinfo.txt записано таке:\n{text}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
