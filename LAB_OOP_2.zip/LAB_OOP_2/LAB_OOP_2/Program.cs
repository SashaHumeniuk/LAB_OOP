﻿static class ArrayExtension
{
    public static int Method(this int[] array)
    {
        Console.WriteLine("Елементи з парними iндексами:");
        for (int i = 0; i < array.Length; i++)
        {
            if ((i % 2) == 0)
            {
                Console.WriteLine($"Елемент {i} = {array[i]}");
            }
        }
        Console.WriteLine("Елементи з непарними iндексами:");
        for (int i = 0; i < array.Length; i++)
        {
            if ((i % 2) != 0)
            {
                Console.WriteLine($"Елемент {i} = {array[i]}");
            }
        }
        return 0;
    }
}

class Program
{
    static void Main(string[] args)
    {
        int[] arr = { 7, 2, 1, 16, 5, 1, 15, 0, 16, 6, 10, 15, 15, 5, 7, 18, 2, 14, 0, 3 };
        ArrayExtension.Method(arr);
    }
}
