﻿class Firma
{
    string firm { get; set; }

    int number { get; set; }
    uint size { get; set; }
    double market { get; set; }

    public Firma(string firm, int number, uint size, double market)
    {
        this.firm = firm;
        this.number = number;
        this.size = size;
        this.market = market;
    }

    public string Output()
    {
        return $"Компанія: {firm}, Кількість. продуктів : {number}, Річний об'єм продажу ($): {size}, Частина ринку (%): {market}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        Firma[] books = {
                new Firma("Oracle ", 1, 2500000000 , 31.01),
                new Firma("IBM ", 3, 2400000000 , 29.25),
                new Firma("Microsoft ", 2, 1000000000 , 13.01),
                new Firma("Компанія4", 2, 1000000000 , 5),
                new Firma("Компанія5", 2, 1000000000 , 5),
                new Firma("Компанія6", 2, 1000000000 , 5),
                new Firma("Компанія7",2 , 1000000000 , 5),
                new Firma("Компанія8", 8, 1000000000 , 5),
                new Firma("Компанія9", 2, 1000000000 , 5),
                new Firma("Компанія10",2, 1000000000 , 1),
            };

        foreach (Firma str in books)
        {
            Console.WriteLine(str.Output());

        }
    }
}
